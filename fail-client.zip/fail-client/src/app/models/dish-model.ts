export class DishModel {
    public constructor(
        public dishID: number,
        public dishName: string
        ) {
    }
}

// (`dishID`, `dishName`)