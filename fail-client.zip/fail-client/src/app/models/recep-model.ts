export class RecepModel {
    public constructor(
        // public recepID?: number,
        public dishID?: number,
        public chefName?: string,
        public recepName?: string,
        public ingredients?: string,
        public preperation?: string
        ) {
    }
}

// (`recepID`, `dishID`, `chefName`, `recepName`, `ingredients`, `preperation`)